
import { AzureFunction, Context } from "@azure/functions";
import { fetchWeeklyTop3 } from "../../lib/news";
import { getThreeFacts } from "../../lib/facts";
import { buildAdaptiveCard } from "../../lib/card";
import { ConnectorClient, MicrosoftAppCredentials } from "botframework-connector";
import { TableClient } from "@azure/data-tables";

const timerTrigger: AzureFunction = async function (context: Context): Promise<void> {
  try {
    const market = process.env.MKT || "en-US";
    const articles = await fetchWeeklyTop3(market);
    const facts = getThreeFacts();
    const card = buildAdaptiveCard(articles, facts);

    const tableConnStr = process.env.TABLE_CONN_STR!;
    const tableName = process.env.TABLE_NAME || "ConversationRefs";
    const tclient = TableClient.fromConnectionString(tableConnStr, tableName);
    const entity = await tclient.getEntity("GroupChat", "Primary");

    const serviceUrl = entity["serviceUrl"] as string;
    const conversationId = entity["conversationId"] as string;
    const appId = process.env.BOT_APP_ID!;
    const appPwd = process.env.BOT_APP_PASSWORD!;

    const credentials = new MicrosoftAppCredentials(appId, appPwd);
    const connector = new ConnectorClient(credentials, { baseUri: serviceUrl });

    const activity = {
      type: "message",
      attachments: [{ contentType: "application/vnd.microsoft.card.adaptive", content: card }]
    } as any;

    await connector.conversations.sendToConversation(conversationId, activity);
    context.log("AI Daily Briefing posted.");
  } catch (e: any) {
    context.log.error("Failed to post daily briefing", e);
    throw e;
  }
};

export default timerTrigger;
